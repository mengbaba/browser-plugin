import './assets/service-worker.ts.js';
